package demo.exceloom;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import lombok.Data;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@SpringBootApplication
@RestController
@RequestMapping("/")
public class DemoExcelOomApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoExcelOomApplication.class, args);
    }

    @RequestMapping(value = "import", method = RequestMethod.POST)
    public ResponseEntity<String> importDataByPoi(MultipartFile file) throws Exception {
        Workbook workbook = WorkbookFactory.create(file.getInputStream());
        Sheet sheetOne = workbook.getSheetAt(0);

        for (int i = 1; i <= sheetOne.getLastRowNum(); i++) {
            Row row = sheetOne.getRow(i);
            // 读取每一行
        }

        return new ResponseEntity<>("ok", HttpStatus.OK);
    }

@Data
public static class ExcelRow {
    @ExcelProperty("name")
    private String name;
    @ExcelProperty("id")
    private String id;
}

@RequestMapping(value = "import-by-easyexcel", method = RequestMethod.POST)
public ResponseEntity<String> importDataByEasyExcel(MultipartFile file) throws Exception {
    final List<ExcelRow> objects = EasyExcel.read(file.getInputStream(), ExcelRow.class, new AnalysisEventListener<ExcelRow>() {

        private int count = 0;
        private final static int maxCount = 100;
        @Override
        public void invoke(ExcelRow data, AnalysisContext context) {
            count++;
        }

        @Override
        public void doAfterAllAnalysed(AnalysisContext context) {

        }

        @Override
        public boolean hasNext(AnalysisContext context) {
            return count <= maxCount;
        }
    }).sheet(0).doReadSync();
    return new ResponseEntity<>("ok,rows:" + objects.size(), HttpStatus.OK);
}

}
