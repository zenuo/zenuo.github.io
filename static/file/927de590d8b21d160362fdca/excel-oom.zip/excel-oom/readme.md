1. compile

```bash
mvn clean package
```

2. start jvm

```bash
/Library/Java/JavaVirtualMachines/jdk-17.0.6.jdk/Contents/Home/bin/java \
    -server -Xms64m -Xmx64m \
    -XX:+HeapDumpOnOutOfMemoryError \
    -jar target/excel-oom-0.0.1-SNAPSHOT.jar
```

3. request with an excel

```bash
curl --location 'localhost:8080/import' --form 'file=@"./test.xlsx"'
```

4. boom!!!

```log
2023-05-28T16:45:38.821+08:00  INFO 27718 --- [nio-8080-exec-2] o.s.web.servlet.DispatcherServlet        : Completed initialization in 1 ms
        java.lang.OutOfMemoryError: Java heap space
Dumping heap to java_pid27718.hprof ...
Heap dump file created [94201075 bytes in 0.246 secs]

Exception: java.lang.OutOfMemoryError thrown from the UncaughtExceptionHandler in thread "Catalina-utility-2"

Exception: java.lang.OutOfMemoryError thrown from the UncaughtExceptionHandler in thread "http-nio-8080-Poller"
Exception in thread "Catalina-utility-1" java.lang.OutOfMemoryError: Java heap space
2023-05-28T16:49:05.855+08:00 ERROR 27718 --- [nio-8080-exec-5] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception [Handler dispatch failed: java.lang.OutOfMemoryError: Java heap space] with root cause
```