package demo.a.service.impl;

import demo.a.dto.ProductDto;
import demo.a.dto.StockDto;
import demo.a.service.IProductService;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * product service implementation
 */
public class ProductServiceImpl implements IProductService {
    @Override
    public ProductDto getProductById(String id) {
        final ProductDto productDto = new ProductDto();
        productDto.id = id;
        productDto.name = UUID.randomUUID().toString();
        productDto.price = BigDecimal.TEN;
        return productDto;
    }

    @Override
    public List<StockDto> getStockByProductId(String productId) {
        final StockDto stockDto = new StockDto();
        stockDto.id = UUID.randomUUID().toString();
        stockDto.productId = productId;
        stockDto.location = "asia";
        stockDto.amount = 9;
        return Collections.singletonList(stockDto);
    }
}
