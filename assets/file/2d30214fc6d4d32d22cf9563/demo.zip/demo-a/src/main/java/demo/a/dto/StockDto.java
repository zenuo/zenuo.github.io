package demo.a.dto;

/**
 * stock dto
 */
public class StockDto {
    public String id;
    public String location;
    public String productId;
    public Integer amount;
}
