package demo.a.service;


import demo.a.dto.ProductDto;
import demo.a.dto.StockDto;

import java.util.List;

/**
 * product service
 */
public interface IProductService {
    ProductDto getProductById(String id);

    List<StockDto> getStockByProductId(String productId);
}
