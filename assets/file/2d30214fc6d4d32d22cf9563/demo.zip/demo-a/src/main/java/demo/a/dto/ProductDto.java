package demo.a.dto;

import java.math.BigDecimal;

/**
 * product dto
 */
public class ProductDto {
    public String id;
    public String name;
    public BigDecimal price;
}
