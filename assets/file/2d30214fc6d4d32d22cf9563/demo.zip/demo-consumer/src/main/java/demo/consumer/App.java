package demo.consumer;

import demo.a.service.IProductService;
import demo.a.service.impl.ProductServiceImpl;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
        final IProductService productService = new ProductServiceImpl();
        System.out.println(productService.getProductById("1").price);
    }
}
